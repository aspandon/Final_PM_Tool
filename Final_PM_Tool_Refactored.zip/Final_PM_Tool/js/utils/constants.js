// js/utils/constants.js
// Re-export from config files for backward compatibility

export { phases, WORKING_DAYS_PER_MONTH } from '../config/phases.js';
export { colors, divisionColors } from '../config/theme.js';