// js/components/ResourcesChart.js

/**
 * ResourcesChart Component
 * Re-exports the modular ResourcesChart from the ResourcesChart directory
 */

export { ResourcesChart } from './ResourcesChart/index.js';