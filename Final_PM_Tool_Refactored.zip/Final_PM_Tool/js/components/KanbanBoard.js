// js/components/KanbanBoard.js
// Re-export from modular structure for backward compatibility
export { KanbanBoard } from './KanbanBoard/index.js';
